from django.contrib.auth.decorators import login_required
from django.db.models import Count
from django.shortcuts import render, redirect
from django.views import View
from django.http import HttpResponse, JsonResponse
from django.contrib import auth
from blog import models
from utils.validCode import valid_code
from blog.myforms import UserForm
from utils.message import message
import random


class Login(View):
    def get(self, request):
        return render(request, "login.html")

    def post(self, request):
        user = request.POST.get('user')
        pwd = request.POST.get('pwd')
        img_code = request.POST.get('code')
        response = {"user": "", "msg": ""}
        code = request.session.get('img_code')
        if img_code.upper() == code.upper():
            user = auth.authenticate(username=user, password=pwd)
            if user:
                auth.login(request, user)  # request.user == 当前登录对象
                response['user'] = user.username
            else:
                response["msg"] = 202
        else:
            response["msg"] = 201
        return JsonResponse(response)


class Sign(View):
    def get(self, request) -> HttpResponse:
        myform = UserForm()
        return render(request, "sign.html", {"form": myform})

    def post(self, request):
        response = {"user": "", "msg": ""}
        fom = UserForm(request.POST)
        if fom.is_valid():
            avatar_obj = request.FILES.get("avatar")
            extra = {}
            if avatar_obj:
                extra["avatar"] = avatar_obj
            models.UserInfo.objects.create_user(username=fom.cleaned_data.get("user"),
                                                password=fom.cleaned_data.get("pwd"),
                                                email=fom.cleaned_data.get("email"),
                                                **extra
                                                )
            response["msg"] = 200
        else:
            print(fom.errors)
            response["msg"] = fom.errors

        return JsonResponse({"data": response})


def imgCode(request):
    code, img = valid_code()
    request.session['img_code'] = code
    return HttpResponse(img)


def index(request):
    article_list = models.Article.objects.all()

    return render(request, "index.html", {"article_list": article_list})


def logout(request):
    auth.logout(request)
    return redirect("/user/login/")


def get_article(username, **keys):
    data = {}
    user_obj = models.UserInfo.objects.filter(username=username).first()
    if not user_obj:
        return HttpResponse("404错误")
    blog = user_obj.blog
    data["blog"] = user_obj.blog
    article = user_obj.article_set
    cid = keys.get("cid")
    tid = keys.get("tid")
    nid = keys.get("nid")
    if cid:
        article_list = article.filter(category=cid)
    elif tid:
        article_list = article.filter(tags=tid)
    elif nid:
        article_list = article.filter(pk=nid)
        if article_list:
            data["is_article"] = 200
        else:
            data["is_article"] = 400
    else:
        article_list = article.all()


    data["username"] = user_obj
    data["article_list"] = article_list  # 文章列表
    data["cate_list"] = models.Category.objects.filter(blog=blog).values("pk").annotate(
        c=Count("article__title")).values_list(
        "title", "c", "nid")
    data["tag_list"] = models.Tag.objects.filter(blog=blog).values("pk").annotate(
        c=Count("article__title")).values_list("title", "c", "nid")
    '''
        # 1使用 extra 函数查看指定时间发表的文章
        ret = models.Article.objects.filter(user=user_obj).extra(select={"is_recent": "create_time > '2022-04-10'"}).values(
            "title", "is_recent")
        print(ret)
    
    # 2使用extra 函数格式化文章创建时间
    ret = models.Article.objects.filter(user=user_obj).extra(
        select={"y_m_d_date": "date_format(create_time,'%%Y-%%m-%%d')"}).values("title", "y_m_d_date")
    print(ret)
    
    # 3.原生sql语句查询指时间文章
    ret = models.Article.objects.raw('select nid,title from blog_article where (create_time >= %s) and user_id=%s',
                                     ["2022-04-21", user_obj.nid])
    for i in ret:
        print("ret", i)
    '''
    from django.db.models.functions import TruncMonth
    ret = models.Article.objects.filter(user=user_obj).annotate(month=TruncMonth("create_time")).values(
        "month").annotate(c=Count("nid")).values_list("title", "month", "c")
    print(ret)
    return data



def userBlog(request, blog_user):
    data = get_article(blog_user)
    print(data)
    return render(request, 'articleList.html', {"data": data})

@login_required
def category(request, username, category_id):
    print(username, category_id)
    data = get_article(username, cid=category_id)

    return render(request, 'articleList.html', {"data": data})


@login_required
def tag(request, username, tag_id):
    data = get_article(username, tid=tag_id)

    return render(request, 'articleList.html', {"data": data})


def article_detail(request, username, article_id):
    data = get_article(username,nid=article_id)

    return render(request,'article_page.html',{"data": data})