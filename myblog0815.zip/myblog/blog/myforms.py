# ！/usr/bin/python3
# -*- coding:utf-8 -*-
"""
@作者：Mr.Chen
@文件名：myforms.py
@时间： 20:26
@描述：
"""
from django import forms
from django.forms import widgets
from django.core.exceptions import NON_FIELD_ERRORS, ValidationError
from blog.models import UserInfo


class UserForm(forms.Form):
    user = forms.CharField(max_length=32, label="账号",
                           widget=widgets.TextInput(attrs={"class": "form-control", "placeholder": "请输入用户名或邮箱"}))
    pwd = forms.CharField(max_length=32, label="密码",
                          widget=widgets.PasswordInput(attrs={"class": "form-control", "placeholder": "请输入密码"}))
    re_pwd = forms.CharField(max_length=32, label="确认密码",
                             widget=widgets.PasswordInput(attrs={"class": "form-control", "placeholder": "请确认密码"}))
    email = forms.EmailField(max_length=32, label="邮箱",
                             widget=widgets.EmailInput(attrs={"class": "form-control", "placeholder": "请输入邮箱"}))

    def clean_user(self):
        username = self.cleaned_data.get("user")
        user = UserInfo.objects.filter(username=username).first()
        if user:
            raise ValidationError("用户名存在")
        return username

    def clean_email(self):
        myemail = self.cleaned_data.get("email")
        email = UserInfo.objects.filter(email=myemail).first()
        if email:
            raise ValidationError("该邮箱已使用")
        return myemail

    def clean(self):
        pwd = self.cleaned_data.get("pwd")
        re_pwd = self.cleaned_data.get("re_pwd")
        if pwd == re_pwd:
            return self.cleaned_data
        else:
            raise ValidationError("两次密码不一样！")
