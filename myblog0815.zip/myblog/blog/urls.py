# ！/usr/bin/python3
# -*- coding:utf-8 -*-
"""
@作者：Mr.Chen
@文件名：urls.py
@时间： 16:33
@描述：
"""
from django.urls import path

from blog import views

# app_name = "User"
urlpatterns = [
    path('login/', views.Login.as_view(), name="login"),
    path('sign/', views.Sign.as_view(), name="sign"),
    path('logout/', views.logout, name="logout"),
    path('imgcode/', views.imgCode, name="imgCode"),
    path('index/', views.index, name='index'),
    path('blog/<str:blog_user>/', views.userBlog, name='user-blog'),
    path('category/<str:username>/<int:category_id>/', views.category, name='category'),
    path('tag/<str:username>/<int:tag_id>/', views.tag, name='tag'),
    path('<str:username>/article/<int:article_id>', views.article_detail, name='acticle_detail'),
]
