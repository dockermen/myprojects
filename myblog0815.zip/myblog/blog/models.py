from django.db import models
from django.contrib.auth.models import AbstractUser


# Create your models here.


class UserInfo(AbstractUser):
    """
    用户信息表
    nid telphone avatar create_time blog
    """
    nid = models.AutoField(primary_key=True)
    telphone = models.CharField(verbose_name="电话", max_length=11, null=True, unique=True)
    avatar = models.FileField(verbose_name="头像", upload_to="avatar/", default="avatar/default.png")
    create_time = models.DateTimeField(verbose_name="注册时间", auto_now_add=True)

    blog = models.OneToOneField(verbose_name="博客", to="Blog", to_field="nid", null=True, on_delete=models.CASCADE)

    class Meta:
        verbose_name_plural = verbose_name = "用户"

    def __str__(self):
        return self.username


class Blog(models.Model):
    """
    博客信息表
    nid title site_name theme
    """
    nid = models.AutoField(primary_key=True)
    title = models.CharField(verbose_name="博客标题", max_length=64)
    site_name = models.CharField(verbose_name="站点名称", max_length=64)
    theme = models.CharField(verbose_name="博客主题", max_length=32)

    class Meta:
        verbose_name_plural = verbose_name = "博客"

    def __str__(self):
        return self.title


class Category(models.Model):
    """
    博主个人文章分类表
    nid title blog
    """
    nid = models.AutoField(primary_key=True)
    title = models.CharField(verbose_name="分类标题", max_length=32)
    blog = models.ForeignKey(verbose_name="所属博客", to="Blog", to_field="nid", on_delete=models.CASCADE)

    class Meta:
        verbose_name_plural = verbose_name = "分类"

    def __str__(self):
        return self.title


class Tag(models.Model):
    """
    文章标签表 多对多
    nid title blog
    """
    nid = models.AutoField(primary_key=True)
    title = models.CharField(verbose_name="标签名称", max_length=32)
    blog = models.ForeignKey(verbose_name="所属博客 ", to="Blog", to_field="nid", on_delete=models.CASCADE)

    class Meta:
        verbose_name_plural = verbose_name = "标签"

    def __str__(self):
        return self.title


class Article(models.Model):
    """
    文章表
    nid title desc create_time update_time content comment_cont up_cont down_cont user category tags
    """
    nid = models.AutoField(primary_key=True)
    title = models.CharField(verbose_name="文章标题", max_length=50)
    desc = models.CharField(verbose_name="文章摘要", max_length=255)
    create_time = models.DateTimeField(verbose_name="发表时间", auto_now_add=True)
    update_time = models.DateTimeField(verbose_name="修改时间", auto_now_add=True, null=True)
    content = models.TextField(verbose_name="文章内容", )

    comment_cont = models.IntegerField(verbose_name="评论数", default=0)
    up_cont = models.IntegerField(verbose_name="点赞数", default=0)
    down_cont = models.IntegerField(verbose_name="踩数", default=0)

    user = models.ForeignKey(verbose_name="作者", to="UserInfo", to_field="nid", on_delete=models.CASCADE)
    category = models.ForeignKey(verbose_name="所属分类", to="Category", to_field="nid", null=True,
                                 on_delete=models.CASCADE)
    tags = models.ManyToManyField(to="Tag", through="Article2Tag", through_fields=("article", "tag"))

    class Meta:
        verbose_name_plural = verbose_name = "文章"

    def __str__(self):
        return self.title


class Article2Tag(models.Model):
    """
    Article Tag 自定义中间表
    nid article tag
    """
    nid = models.AutoField(primary_key=True)
    article = models.ForeignKey(verbose_name="文章", to="Article", to_field="nid", on_delete=models.CASCADE)
    tag = models.ForeignKey(verbose_name="标签", to="Tag", to_field="nid", on_delete=models.CASCADE)

    class Meta:
        verbose_name_plural = verbose_name = "文章标签中间表"
        unique_together = [("article", "tag"), ]


class ArticleUpDown(models.Model):
    """
    文章点赞表
    nid user article is_up
    """
    nid = models.AutoField(primary_key=True)
    user = models.ForeignKey("UserInfo", null=True, on_delete=models.CASCADE)
    article = models.ForeignKey("Article", null=True, on_delete=models.CASCADE)
    is_up = models.BooleanField(default=True)

    class Meta:
        verbose_name_plural = verbose_name = "点赞"
        unique_together = [("user", "article"), ]


class Comment(models.Model):
    """
    文章评论表
    nid user article content create_time parent_comment
    """
    nid = models.AutoField(primary_key=True)
    user = models.ForeignKey(verbose_name="评论者", to="UserInfo", to_field="nid", on_delete=models.CASCADE)
    article = models.ForeignKey(verbose_name="评论文章", to="Article", to_field="nid", on_delete=models.CASCADE)
    content = models.CharField(verbose_name="评论内容", max_length=255)
    create_time = models.DateTimeField(verbose_name="评论时间", auto_now_add=True)
    parent_comment = models.ForeignKey("self",verbose_name="父评论",  null=True, on_delete=models.CASCADE)

    class Meta:
        verbose_name_plural = verbose_name = "评论"

    def __str__(self):
        return self.content
